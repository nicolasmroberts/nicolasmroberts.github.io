
source("library/all.R")


Follins <- geoDataFromFile("data/thinSectionsToOrient.csv")
xzyzSD <- data.frame(
                     Location = Follins$location,
                     Comments = Follins$comments,
                     Strike = Follins$strikeDeg,
                     Dip = Follins$dipDeg,
                     Rake = Follins$rakeDeg,
                     xzStrike = integer(nrow(Follins)),
                     xzDip = integer(nrow(Follins)),
                     yzStrike = integer(nrow(Follins)),
                     yzDip = integer(nrow(Follins))
                   )


for (i in 1:nrow(Follins)){
xzPole <- cross(Follins$direction[[i]], Follins$pole[[i]])
yzPole <- Follins$direction[[i]]

xz <- geoStrikeDipDegFromCartesian(xzPole)
yz <- geoStrikeDipDegFromCartesian(yzPole)

xzyzSD$xzStrike[[i]] <- xz[1]
xzyzSD$xzDip[[i]] <- xz[2]
xzyzSD$yzStrike[[i]] <- yz[1]
xzyzSD$yzDip[[i]] <- yz[2]

}

